import React, { useState } from "react";
import "./App.css";

function App() {
  const [result, setResult] = useState("");

  const handleSubmit = async () => {
    try {
      const response = await fetch("http://localhost:8000/predict", {
        method: "POST",
      });
      const data = await response.json();
      setResult(data.result);
    } catch (error) {
      console.error("Error", error);
    }
  };

  return (
    <div className="appBlock">
      <button className="submitBtn" onClick={handleSubmit}>
        Submit
      </button>
      <p className="resultOutput">Result: {result}</p>
    </div>
  );
}

module.exports = App;
